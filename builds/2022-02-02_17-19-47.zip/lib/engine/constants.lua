_dbg_rb = true
_dbg_col = false
_dbg_gun = false
_dbg_anim_ctl = false
_dbg_systems = false
_dbg_ctl = false

m_all = 0xff
m_world = 0x01
m_enemy = 0x02
m_player = 0x04
m_projectile = 0x08
m_shrapnel = 0x16

grav = 300
air_accel = 200
gnd_accel = 100
walkspeed = 60
jump_v = 90
max_jump_time = .15
screen_shake = 0
explosion_speed = 60
explosion_angles = 4
explosion_rs = 1
